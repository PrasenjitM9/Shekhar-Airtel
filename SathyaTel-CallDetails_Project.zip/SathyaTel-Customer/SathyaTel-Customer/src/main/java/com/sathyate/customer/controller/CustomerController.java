package com.sathyate.customer.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.client.RestTemplate;

import com.sathyatel.customer.dto.CustomerDTO;

public class CustomerController {
	@Autowired
	private RestTemplate restTemplate;
	@Autowired
	private CustomerService service;
	
	@PostMapping (value="/saveCustomer", consumes="application/JSON")
	public String saveCustomer(@RequestBody Customer customer) {
		return service.saveCustomer(customer);
		}
	@GetMapping(value="viewProfile/{phoneNo}", produces)
	public CustomerDTO viewProfile(@PathVariable Long phoneNo ){
		CustomerDTO dto=service.getCustomerByPhoneNo(phoneNo);
		//Calling sathya.pla microservice
		PlanDTO planDto= restTemplate.getForObject("http://PlanMService, responseType)")
				dto.setCurrentPlan(planDto);
		//calling sathay friend microservice
		List<Long> friendList=restTemplate.getForObject("http://FriendMService,");
		dto.setFriend(friendDto);
		return dto;
	}
	

}
