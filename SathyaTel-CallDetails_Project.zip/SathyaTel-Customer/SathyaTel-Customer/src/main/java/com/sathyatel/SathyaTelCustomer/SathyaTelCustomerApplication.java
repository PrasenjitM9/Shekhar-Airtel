package com.sathyatel.SathyaTelCustomer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SathyaTelCustomerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SathyaTelCustomerApplication.class, args);
	}

}

