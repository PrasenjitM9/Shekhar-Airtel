package com.sathyatel.friend.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.sathyatel.friend.service.FriendService;

public class FriendController {
	@Autowired
	private FriendService service;
	@GetMapping(value="/friend/{friendName}", produces="application/JSON") 
	public List<> findByPhoneNO(@PathVariable Long Friend) {
		return service.getFriends(phoneno);
	}
	

}
