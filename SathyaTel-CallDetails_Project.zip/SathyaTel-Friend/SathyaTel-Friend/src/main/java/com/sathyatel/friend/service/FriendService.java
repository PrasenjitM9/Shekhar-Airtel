package com.sathyatel.friend.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sathyatel.friend.entity.Friend;
import com.sathyatel.friend.repository.FriendRepository;
@Service
public class FriendService {
	@Autowired
private FriendRepository repo;
	
	
}
