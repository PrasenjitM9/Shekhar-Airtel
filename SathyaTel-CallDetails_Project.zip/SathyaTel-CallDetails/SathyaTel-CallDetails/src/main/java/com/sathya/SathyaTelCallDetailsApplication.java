package com.sathya;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SathyaTelCallDetailsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SathyaTelCallDetailsApplication.class, args);
	}

}

