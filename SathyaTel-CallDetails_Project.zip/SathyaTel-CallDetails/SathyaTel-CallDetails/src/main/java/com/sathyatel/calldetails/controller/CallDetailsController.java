package com.sathyatel.calldetails.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.sathyatel.calldetails.dto.CallDetailsDTO;
import com.sathyatel.calldetails.service.CallDetailsService;
@RestController
public class CallDetailsController {
	@Autowired
	private CallDetailsService service;
	
	@GetMapping(value="/calldetails/{calledby}", produces="application/JSON")
	public List<CallDetailsDTO> getCallDetailsByCalledBy(@PathVariable Long calledBy) {
		return service.getCallDetailsByCalledBy(calledBy);
		
		//List<CallDetails>
	}
}
