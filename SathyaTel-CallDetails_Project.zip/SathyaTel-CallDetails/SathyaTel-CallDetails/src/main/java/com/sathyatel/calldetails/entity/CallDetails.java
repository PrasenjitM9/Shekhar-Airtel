package com.sathyatel.calldetails.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="call_details")
public class CallDetails {
	@Id
	@Column(name="called_id")
	private Long calledId;
	
	@Column(name="called_by")
	private Long calledBy;
	
	@Column(name="called_to")
	private Long calledTo;

	@Column(name="called_on")
	@Temporal(TemporalType.DATE)
	private Date date;
	
	@Column(name="duration")
	private int duration;

	public Long getCalledId() {
		return calledId;
	}

	public void setCalledId(Long calledId) {
		this.calledId = calledId;
	}

	public Long getCalledBy() {
		return calledBy;
	}

	public void setCalledBy(Long calledBy) {
		this.calledBy = calledBy;
	}

	public Long getCalledTo() {
		return calledTo;
	}

	public void setCalledTo(Long calledTo) {
		this.calledTo = calledTo;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public int getDuration() {
		return duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}
}