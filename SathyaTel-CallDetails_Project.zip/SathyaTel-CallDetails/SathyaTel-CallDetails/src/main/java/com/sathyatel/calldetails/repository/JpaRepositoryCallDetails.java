package com.sathyatel.calldetails.repository;

public class JpaRepositoryCallDetails {

}
