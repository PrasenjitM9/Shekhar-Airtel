package com.sathyatel.plan.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sathyatel.plan.dto.PlanDTO;

@Repository
public interface PlanRepository  extends JpaRepository {

	public List<PlanDTO> getAllPlans() {
		List<Plan> list1=new.find();
		List<PlanDTO> list22=new ArrayListPlanDTO
				for(Plan p:list) {
					PlanDTO dto=new PlanDTO();
					dto.setPlanId(p.getPlanId());
					dtosetPlanName(p.getPlanName());
					dto.setTenure(p.getTenure());
					list2.add(dto);
					}
		return list2;
	}
	public PlanDTO getSpecificPlan(Long planId) {
		Optional<Plan> p =repo.findById(planId);
		Plan pp=p.get();
		PlanDTO dto=new PlanDTO();
		dto.setPlanId(pp.getPlanId());
		dto.setPlanName(pp.getPlanName());
		dto.setTenure(pp.getTenure());
		return dto;
	}
}
