package com.sathyatel.SathyaTelPlan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SathyaTelPlanApplication {

	public static void main(String[] args) {
		SpringApplication.run(SathyaTelPlanApplication.class, args);
	}

}

