package com.sathyatel.plan.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.sathyatel.plan.dto.PlanDTO;
import com.sathyatel.plan.repository.PlanRepository;

public class PlanService {
	@Autowired
	private PlanRepository repo;
	public List<PlanDTO> getAllPlans getPlan(Long plan) {
		List<Plans> list1=repo.findAll(plan);
		List<PlanDTO> list2=new ArryaList<CallDetailsDTO>();
		for(PlanDetails pd:list1) {
			PlanDetailsDTO dto=new PlanDetailsDTO();
			
		}
	}
}
/* @Autowired
	private CallDetailsRepository repo;
	
	public List<CallDetailsDTO> getCallDetailsByCalledBy(Long calledBy) {
	List<CallDetails> list1 = repo.findByCalledBy(calledBy);
	List<CallDetailsDTO> list2 = new ArrayList<CallDetailsDTO>();
	
	for(CallDetails cd : list1) {
		CallDetailsDTO dto=new CallDetailsDTO();
		
		dto.setCalledId(cd.getCalledId());
		dto.setCalledBy(cd.getCalledBy());
		dto.setCalledTo(cd.getCalledTo());
		dto.setCalledOn(cd.getDate());
		dto.setDuration(cd.getDuration());
		list2.add(dto);
	}
	return list2;
	*/
