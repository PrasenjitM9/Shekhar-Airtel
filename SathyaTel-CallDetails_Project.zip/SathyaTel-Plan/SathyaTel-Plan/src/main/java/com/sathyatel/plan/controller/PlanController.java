package com.sathyatel.plan.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.sathyatel.calldetails.dto.CallDetailsDTO;
import com.sathyatel.plan.dto.PlanDTO;
import com.sathyatel.plan.service.PlanService;

public class PlanController {
	@Autowired
	private PlanService service;
	
	@GetMapping(value="/plans", produces="application/JSON")
	public List<PlanDTO> getAllPlans() {
		return service.getAllPlans();
	}
	@GetMapping(value="/plans/{planId}"}, produces="application/JSON")
	public PlanDTO getSpecificPlan(@PathVariable Long) {
		return service.getSpecificPlan(planId);
	}

}

/* @GetMapping(value="/calldetails/{calledby}", produces="application/JSON")
public List<CallDetailsDTO> getCallDetailsByCalledBy(@PathVariable Long calledBy) {
return service.getCallDetailsByCalledBy(calledBy);
*/