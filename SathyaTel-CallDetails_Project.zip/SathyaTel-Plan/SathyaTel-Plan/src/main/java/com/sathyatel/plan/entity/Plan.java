package com.sathyatel.plan.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="plan_details")
public class Plan {
	@Id
	@Column(name="plan_id")
	private int id;
	
	@Column(name="plan_name")
	private String planName;
	
	@Column(name="tenure")
	private String tenure;
}
